﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SwitchState : MonoBehaviour
{
    public static Animator swisAnim;
    void Start()
    {
        swisAnim = gameObject.GetComponent<Animator>();
    }
}
