﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class PlayerScript : MonoBehaviour
{
    public GameObject Camera;
    public int speed;
    public int lives;
    //public int score;
    public int item;
    public float timeLeft;
    public int timeRemaining;
    private float TimerValue;

    public Text txtLives;
    //public Text txtScore;
    public Text txtItem;
    public Text txtTime;
    public bool timerBool = false;

    public GameObject Door;
    public GameObject showText;
    public Text changeText;

    public AudioSource aud;
    public AudioClip[] adios;

    void Start()
    {
        aud = GetComponent<AudioSource>();
        lives = 3;
        if (SceneManager.GetActiveScene().name == "Gameplay_Level2")
        {
            timerBool = true;
            timeLeft = 20;
        }
        if (SceneManager.GetActiveScene().name == "Gameplay_Level3")
        {
            timerBool = true;
            timeLeft = 30;
        }
    }

    void Update()
    {
        if (Input.GetKey(KeyCode.W))
        {
            transform.position += transform.up * Time.deltaTime * speed;
        }
        if (Input.GetKey(KeyCode.S))
        {
            transform.position -= transform.up * Time.deltaTime * speed;
        }
        if (Input.GetKey(KeyCode.A))
        {
            transform.localScale = new Vector2(-0.2793075f, 0.2793075f); /* Flips sprite to the left */
            transform.position -= transform.right * Time.deltaTime * speed;
        }
        if (Input.GetKey(KeyCode.D))
        {
            transform.localScale = new Vector2(0.2793075f, 0.2793075f); /* Flips sprite to the right */
            transform.position += transform.right * Time.deltaTime * speed;
        }
        txtLives.text = "Lives: " + lives;
        //txtScore.text = "Score: " + score;
        txtItem.text = "Items: " + item;

        if (timerBool == true)
        {
            timeLeft -= Time.deltaTime;
            timeRemaining = Mathf.FloorToInt(timeLeft % 60);
            txtTime.text = "Timer: " + timeRemaining.ToString();
        }
        if (timeLeft <= 0)
        {
            if (timerBool == true)
            {
                SceneManager.LoadScene("GameLose");
            }
        }
        if (lives == 0)
        {
            SceneManager.LoadScene("GameLose");
        }
    }

    public void OnCollisionEnter2D(Collision2D collision)
    {
        if (collision.gameObject.tag == "Trap")
        {
            lives--;
            aud.PlayOneShot(adios[0]);
        }
        if (collision.gameObject.tag == "Enemy")
        {
            lives--;
            aud.PlayOneShot(adios[0]);
        }
        if (collision.gameObject.tag == "TimeBoost")
        {
            timeLeft += 5;
            aud.PlayOneShot(adios[2]);
            Destroy(collision.gameObject);
        }

        // Collectibles for Each Level
        if (collision.gameObject.tag == "Collectible")
        {
            aud.PlayOneShot(adios[1]);
            item++;
            //score = score + 5;
            changeText.text = item + "/3";
            Destroy(collision.gameObject);
            if (item >= 3)
                changeText.color = Color.green;
        }
        if (collision.gameObject.tag == "Collectible2")
        {
            aud.PlayOneShot(adios[1]);
            item++;
            //score = score + 5;
            changeText.text = item + "/5";
            Destroy(collision.gameObject);
            if (item >= 5)
                changeText.color = Color.green;
        }
        if (collision.gameObject.tag == "Collectible3")
        {
            aud.PlayOneShot(adios[1]);
            item++;
            //score = score + 5;
            changeText.text = item + "/10";
            Destroy(collision.gameObject);
            if (item >= 10)
                changeText.color = Color.green;
        }

        // Head to Level 2
        if (collision.gameObject.tag == "Next1")
        {
            SceneManager.LoadScene("Gameplay_Level2");
        }

        // Head to Level 3
        if (collision.gameObject.tag == "Next2") 
        {
            SceneManager.LoadScene("Gameplay_Level3");
        }

        // Goes to Game Win Scene
        if (collision.gameObject.tag == "EndGoal")
        {
            if (timeLeft >= TimerValue)
            {
                SceneManager.LoadScene("GameWin");
            }
        }
        // Teleports Player and Moves Camera
        if (collision.gameObject.tag == "TP")
        {
            Movement(7.5f, -13f, 0f, -9.2f, -10f);
        }
    }

    private void Movement(float x1, float y1, float x2, float y2, float z1)
    {
        transform.position = new Vector2(x1, y1);
        Camera.transform.position = new Vector3(x2, y2, z1);
    }
    private void OnTriggerEnter2D(Collider2D collision)
    {
        if (collision.gameObject.tag == "Switch")
        {
            showText.SetActive(true);
            if (item < 3)
                changeText.color = Color.red;
        }
        if (collision.gameObject.tag == "Switch2")
        {
            showText.SetActive(true);
            if (item < 5)
                changeText.color = Color.red;
        }
        if (collision.gameObject.tag == "Switch3")
        {
            showText.SetActive(true);
            if (item < 10)
                changeText.color = Color.red;
        }
    }
    private void OnTriggerStay2D(Collider2D collision)
    {
        if (SceneManager.GetActiveScene().name == "Gameplay_Level1")
        {
            if (item >= 3)
            {
                if (Input.GetKeyDown(KeyCode.Space))
                {
                    SwitchActivate();
                }
            }
        }
        if (SceneManager.GetActiveScene().name == "Gameplay_Level2")
        {
            if (item >= 5)
            {
                if (Input.GetKeyDown(KeyCode.Space))
                {
                    SwitchActivate();
                }
            }
        }
        if (SceneManager.GetActiveScene().name == "Gameplay_Level3")
        {
            if (item >= 10)
            {
                if (Input.GetKeyDown(KeyCode.Space))
                {
                    SwitchActivate();
                }
            }
        }
    }
    private void SwitchActivate()
    {
        Destroy(Door.gameObject);
        aud.PlayOneShot(adios[3]);
        SwitchState.swisAnim.SetBool("Switched", true);
    }
}
