﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class PlayerScriptTest : MonoBehaviour
{
    public int speed = 5;
    public int score;
    public float timer;
    public bool timerBool = false;
    public GameObject Door;
    public GameObject showText;
    public Text changeText;
    public Text timerText;

    // Start is called before the first frame update
    void Start()
    {
        if(SceneManager.GetActiveScene().name == "Gameplay_Level2")
        {
            timerBool = true;
            timer = 20;
        }

        if (SceneManager.GetActiveScene().name == "Gameplay_Level3")
        {
            timerBool = true;
            timer = 30;
        }
    }

    // Update is called once per frame
    void Update()
    {
        float horizontalInput = Input.GetAxis("Horizontal");
        float verticalInput = Input.GetAxis("Vertical");
        Vector2 direction = new Vector2(horizontalInput, verticalInput);
        transform.Translate(direction * speed * Time.deltaTime);

        if (timerBool)
        {
            timer -= Time.deltaTime;
            timerText.text = "Timer: " + Mathf.RoundToInt(timer);
        }

        if(timer<= 0)
        {
            SceneManager.LoadScene("Gameplay_Level2"); // need 2 change to game lose
        }

    }

    private void OnCollisionEnter2D(Collision2D collision)
    {
        if(collision.gameObject.tag == "Collectible")
        {
            score++;
            changeText.text = score + "/3";
            Destroy(collision.gameObject);
            if (score >= 3)
                changeText.color = Color.green;
        }


        if (collision.gameObject.tag == "EndGoal")
        {
            SceneManager.LoadScene("Gameplay_Level2"); // need 2 change to level 3
        }

        if (collision.gameObject.tag == "Enemy")
        {
            SceneManager.LoadScene("Gameplay_Level2"); // need 2 change to game lose
        }

        if(collision.gameObject.tag == "TimeBoost")
        {
            timer += 5;
            Destroy(collision.gameObject);
        }
    }

    private void OnTriggerEnter2D(Collider2D collision)
    {
        if (collision.gameObject.tag == "Switch")
        {
            showText.SetActive(true);
            if (score < 3)
             changeText.color = Color.red;
        }
    }

    private void OnTriggerStay2D(Collider2D collision)
    {
        if (score >= 3)
            {
                if (Input.GetKeyDown(KeyCode.Space))
                    Destroy(Door.gameObject);
            }
    }

}
