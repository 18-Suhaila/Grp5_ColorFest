﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Audio;
using TMPro;
using UnityEngine.SceneManagement;

public class SpawnObject : MonoBehaviour
{
    public GameObject particle;
    public AudioClip audioclip;
    public AudioClip audioclip1;
    public AudioSource audiosource;
    private float score;
    private int coin;
    private int health=3;
    public TextMeshProUGUI ScoreText;
    public TextMeshProUGUI HealthText;
    public TextMeshProUGUI GameOverText;
    public TextMeshProUGUI CollectiblesText;
    public TextMeshProUGUI CollectiblesInfoText;
    public TextMeshProUGUI RestartText;
    // Start is called before the first frame update
    void Start()
    {

    }

    // Update is called once per frame
    void Update()
    {
        if (health == 0)
        {
            GameOverText.GetComponent<TextMeshProUGUI>().text = "Game Over ";
            Time.timeScale = 0;
        }
        ScoreText.GetComponent<TextMeshProUGUI>().text = "Score : "+score;
        HealthText.GetComponent<TextMeshProUGUI>().text = "Health : " + health;
        CollectiblesText.GetComponent<TextMeshProUGUI>().text = "Collectible: " + coin;
    }
    public void OnCollisionEnter2D (Collision2D collision)
    {
        if(collision.gameObject.CompareTag("Collectible"))
        {
            Destroy(collision.gameObject);
            coin++;
            score += 100;
            audiosource.clip = audioclip;
            audiosource.Play();
            Instantiate(particle, collision.transform.position, Quaternion.identity);
        }
    }
    public void OnTriggerStay2D(Collider2D other)
        {
        if (other.gameObject.CompareTag("Door"))
        {
            if (coin <= 5)
            {
                CollectiblesInfoText.enabled = true;
                CollectiblesInfoText.GetComponent<TextMeshProUGUI>().text = "need 6 collectibles ";
            }
            else if (coin == 6)
            {
                //6 collectibles load next scene
                SceneManager.LoadScene(""); 
            }
        }
    }
    public void OnTriggerExit2D(Collider2D other)
    {
        if (other.gameObject.CompareTag("Door"))
        {
            if (coin <= 5)
            {
                CollectiblesInfoText.enabled = false;
            }
        }
    }
    public void OnTriggerEnter2D(Collider2D other)
    {
        if (other.gameObject.CompareTag("Trap"))
        {
            health -= 1;
            audiosource.clip = audioclip1;
            audiosource.Play();
        }
    }
}
