﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ObstacleMovement : MonoBehaviour
{
    public float leftX;
    public float rightX;
    public int moveSpeed;
    private bool movingLeft;
    private Vector3 dir = Vector3.left;

    void Start()
    {
        movingLeft = true;
    }
    void Update()
    {
        transform.Translate(dir * moveSpeed * Time.deltaTime);

   
        if (transform.position.x <= leftX) // when x position is lesser than leftX, change direction to right
        {
            movingLeft = false;
        }
        else if (transform.position.x >= rightX) // when x position is more than rightX, change direction to left 
        {
            movingLeft = true;

        }

        if (movingLeft == true)
        {
            dir = Vector3.left;
        }
        else
        {
            dir = Vector3.right;
        }
    }
}
