﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class Buttons : MonoBehaviour
{
    public GameObject Inst;
    public GameObject MainBtns;
    void Start()
    {
        
    }
    void Update()
    {
        
    }

    public void GameStart()
    {
        SceneManager.LoadScene("Gameplay_Level1");
    }
    public void Instructions()
    {
        Inst.SetActive(true);
        MainBtns.SetActive(false);
    }
    public void Back()
    {
        Inst.SetActive(false);
        MainBtns.SetActive(true);
    }
    public void Restart()
    {
        SceneManager.LoadScene("Gameplay_Level1");
    }

    public void Home()
    {
        SceneManager.LoadScene("MainMenu");
    }
    public void Quit()
    {
        Application.Quit();
    }
}
